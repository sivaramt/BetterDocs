public class b {
	Integer b=1;
}