public class A {
	Integer a =0;
}