public class B {
	Integer b=1;
}